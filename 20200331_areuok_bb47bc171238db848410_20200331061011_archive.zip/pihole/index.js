var x = "Pi-hole: A black hole for Internet advertisements."
